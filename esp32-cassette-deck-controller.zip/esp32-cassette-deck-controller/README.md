# ESP32 Cassette Deck Controller – Hardware & Firmware Project

An ESP32-based controller project demonstrating modular firmware for cassette-deck control functions.

## Project Overview

- ESP32-based embedded controller.
- Arduino framework.
- Modular C++ controller class.
- Control functions for:
  - PLAY
  - STOP
  - PAUSE
  - REWIND
  - FAST FORWARD
  - EJECT
- Serial command interface for development/testing.
- Placeholder GPIO mapping that can be changed easily.
- Separate header and source files.
- PlatformIO configuration included.

## Important Hardware Note

The GPIO assignments in this repository are **placeholders only**.

They are not claimed to be the verified pin mapping of the cassette-deck hardware described in the DigitalMonk case study. Before connecting an ESP32 to real hardware, verify the interface, voltage levels, polarity, isolation/driver requirements, and pin mapping from the actual hardware documentation.

The sample firmware assumes that each control output can be represented by a simple digital pulse. This is a software abstraction for testing and must be adapted to the verified hardware interface.

## Project Structure

```text
esp32-cassette-deck-controller/
├── esp32-cassette-deck-controller.ino
├── platformio.ini
├── README.md
├── include/
│   └── cassette_controller.h
└── src/
    ├── cassette_controller.cpp
    └── main.cpp
```

## Arduino IDE

1. Install ESP32 board support in Arduino IDE.
2. Open `esp32-cassette-deck-controller.ino`.
3. Select an ESP32 development board.
4. Replace the placeholder GPIO values with the verified mapping for your hardware.
5. Compile and upload.
6. Open Serial Monitor at `115200` baud.

## Serial Commands

Send one command per line:

```text
play
stop
pause
rewind
ff
eject
```

The firmware prints the selected command to the Serial Monitor and generates a short output pulse on the corresponding placeholder GPIO.

## PlatformIO

Build:

```bash
pio run
```

Upload:

```bash
pio run --target upload
```

Open Serial Monitor:

```bash
pio device monitor
```

## Customizing GPIOs

GPIO assignments are defined near the top of:

```text
esp32-cassette-deck-controller.ino
```

Example:

```cpp
namespace Pins {
constexpr uint8_t PLAY     = 25;
constexpr uint8_t STOP     = 26;
constexpr uint8_t PAUSE    = 27;
constexpr uint8_t REWIND   = 32;
constexpr uint8_t FAST_FWD = 33;
constexpr uint8_t EJECT    = 14;
}
```

Replace these values only after confirming the actual hardware interface.

## Development Status

This repository is a clean firmware/project template based on the control functions described for the ESP32 cassette-deck controller concept. Hardware-specific implementation details should be added only after they are verified from the actual project hardware and documentation.

## Case Study

[ESP32 Cassette Deck Controller](https://digitalmonk.biz/case-study-esp32-cassette-deck-controller/)

## Development Support

If you need to [hire Arduino programmer](https://digitalmonk.biz/hire-arduino-developer/) for an embedded hardware or firmware project, DigitalMonk can help with Arduino, ESP32, and embedded system development.
