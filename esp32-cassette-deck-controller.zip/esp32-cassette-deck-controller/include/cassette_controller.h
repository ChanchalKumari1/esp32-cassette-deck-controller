#pragma once

#include <Arduino.h>

/**
 * Modular controller for an ESP32-based cassette deck interface.
 *
 * IMPORTANT:
 * The pin numbers and output behavior in this project are placeholders.
 * Verify the actual hardware interface before connecting the ESP32.
 */
class CassetteController {
public:
    CassetteController(
        uint8_t playPin,
        uint8_t stopPin,
        uint8_t pausePin,
        uint8_t rewindPin,
        uint8_t fastForwardPin,
        uint8_t ejectPin
    );

    void begin();
    void update();

    void play();
    void stop();
    void pause();
    void rewind();
    void fastForward();
    void eject();

private:
    uint8_t _playPin;
    uint8_t _stopPin;
    uint8_t _pausePin;
    uint8_t _rewindPin;
    uint8_t _fastForwardPin;
    uint8_t _ejectPin;

    void pulse(uint8_t pin);
};
