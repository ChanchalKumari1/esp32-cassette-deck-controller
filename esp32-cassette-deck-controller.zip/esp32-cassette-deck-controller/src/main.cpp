#include <Arduino.h>

// PlatformIO entry point.
// The project uses the root .ino file as the main application.
// This file intentionally contains no duplicate setup()/loop() functions.
