#include "cassette_controller.h"

namespace {
constexpr uint16_t COMMAND_PULSE_MS = 100;
}

CassetteController::CassetteController(
    uint8_t playPin,
    uint8_t stopPin,
    uint8_t pausePin,
    uint8_t rewindPin,
    uint8_t fastForwardPin,
    uint8_t ejectPin
)
    : _playPin(playPin),
      _stopPin(stopPin),
      _pausePin(pausePin),
      _rewindPin(rewindPin),
      _fastForwardPin(fastForwardPin),
      _ejectPin(ejectPin) {}

void CassetteController::begin() {
    const uint8_t pins[] = {
        _playPin,
        _stopPin,
        _pausePin,
        _rewindPin,
        _fastForwardPin,
        _ejectPin
    };

    for (uint8_t pin : pins) {
        pinMode(pin, OUTPUT);
        digitalWrite(pin, LOW);
    }
}

void CassetteController::update() {
    // Reserved for future physical-button input handling,
    // debouncing, state feedback, or sensor integration.
}

void CassetteController::pulse(uint8_t pin) {
    digitalWrite(pin, HIGH);
    delay(COMMAND_PULSE_MS);
    digitalWrite(pin, LOW);
}

void CassetteController::play() {
    Serial.println("PLAY");
    pulse(_playPin);
}

void CassetteController::stop() {
    Serial.println("STOP");
    pulse(_stopPin);
}

void CassetteController::pause() {
    Serial.println("PAUSE");
    pulse(_pausePin);
}

void CassetteController::rewind() {
    Serial.println("REWIND");
    pulse(_rewindPin);
}

void CassetteController::fastForward() {
    Serial.println("FAST FORWARD");
    pulse(_fastForwardPin);
}

void CassetteController::eject() {
    Serial.println("EJECT");
    pulse(_ejectPin);
}
