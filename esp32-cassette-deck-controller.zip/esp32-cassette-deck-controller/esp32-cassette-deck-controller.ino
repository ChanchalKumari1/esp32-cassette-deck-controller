#include <Arduino.h>
#include "cassette_controller.h"

// -----------------------------------------------------------------------------
// IMPORTANT:
// GPIO values below are PLACEHOLDERS ONLY.
// Replace them with the verified pin mapping for your actual cassette hardware.
// No electrical specifications are assumed by this example.
// -----------------------------------------------------------------------------

namespace Pins {
constexpr uint8_t PLAY     = 25;
constexpr uint8_t STOP     = 26;
constexpr uint8_t PAUSE    = 27;
constexpr uint8_t REWIND   = 32;
constexpr uint8_t FAST_FWD = 33;
constexpr uint8_t EJECT    = 14;
}

CassetteController cassette(
    Pins::PLAY,
    Pins::STOP,
    Pins::PAUSE,
    Pins::REWIND,
    Pins::FAST_FWD,
    Pins::EJECT
);

void setup() {
    Serial.begin(115200);
    delay(200);

    cassette.begin();

    Serial.println();
    Serial.println("ESP32 Cassette Deck Controller");
    Serial.println("GPIO mapping is placeholder data.");
    Serial.println("Replace it with the verified hardware mapping.");
    Serial.println("Commands: play, stop, pause, rewind, ff, eject");
}

void loop() {
    cassette.update();

    // Simple serial command interface for development/testing.
    if (Serial.available()) {
        String command = Serial.readStringUntil('\n');
        command.trim();
        command.toLowerCase();

        if (command == "play") {
            cassette.play();
        } else if (command == "stop") {
            cassette.stop();
        } else if (command == "pause") {
            cassette.pause();
        } else if (command == "rewind") {
            cassette.rewind();
        } else if (command == "ff" || command == "fastforward") {
            cassette.fastForward();
        } else if (command == "eject") {
            cassette.eject();
        } else {
            Serial.println("Unknown command.");
        }
    }
}
